﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Text.Json;
using GymProAPI.GlobalCode;
using GymProAPI.Model.User;
using GymProAPI.Parameters.User;

namespace GymProAPI.Controllers.User 
{
    [Route("[controller]")]
    [ApiController]
    public class LoginApiController : ControllerBase
    {
        private readonly DBResponse db;
        public LoginApiController(DBResponse db)
        {
            this.db = db;
        }

        [HttpPost("[Action]")]
        public async Task<IActionResult> Login(UserModel objE)
        {
            var Params = new Parameter_login().Parameters(objE);
            var dt = await db.Result("Proc_User_login", Params);
            var Json = await db.JsonConverter(dt);
            return Json;
        }
    }
}
