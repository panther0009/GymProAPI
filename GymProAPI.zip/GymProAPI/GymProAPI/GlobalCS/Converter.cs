﻿using System.Data;
using System.Reflection;

namespace GymProAPI.GlobalCode
{
    public class Converter
    {
        public DataTable ConvertListToDataTable<T>(List<T> list)
        {
            DataTable dataTable = new DataTable();
            PropertyInfo[] properties = typeof(T).GetProperties();

            foreach (PropertyInfo property in properties)
            {
                Type propertyType = property.PropertyType;

                // Check if the property type is nullable
                if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    // Use the underlying non-nullable type
                    propertyType = Nullable.GetUnderlyingType(propertyType);
                }

                dataTable.Columns.Add(property.Name, propertyType);
            }

            foreach (T item in list)
            {
                DataRow row = dataTable.NewRow();

                foreach (PropertyInfo property in properties)
                {
                    object value = property.GetValue(item);

                    // Check if the value is null and replace it with DBNull.Value
                    if (value == null)
                    {
                        row[property.Name] = DBNull.Value;
                    }
                    else
                    {
                        row[property.Name] = value;
                    }
                }

                dataTable.Rows.Add(row);
            }

            return dataTable;
        }
    }
}
