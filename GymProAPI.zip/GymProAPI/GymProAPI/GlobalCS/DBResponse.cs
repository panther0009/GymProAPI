﻿using Microsoft.AspNetCore.Mvc;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using System.Text.Json;

namespace GymProAPI.GlobalCode
{
    public class DBResponse
    {
        public string Conn { get; set; } = string.Empty;
        public DBResponse(string conn)
        {
            this.Conn = conn;
        }

        public async Task<DataTable> Result(string SP, IEnumerable<SqlParameter>? Params = null)
        {

                var dt = new DataTable();
            try
            {
                using var cnn = new SqlConnection(this.Conn);
                using var adaptor = new SqlDataAdapter(SP, cnn);
                adaptor.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (Params != null)
                {
                    foreach (var param in Params)
                    {
                        adaptor.SelectCommand.Parameters.AddWithValue(param.ParameterName, param.Value);
                    }
                }
                await cnn.OpenAsync();
                adaptor.Fill(dt);
            }
            catch (Exception e)
            {
                //  Block of code to handle errors
                var result = e.Message;
            }
            return dt;
        }
        public async Task<DataTable> Resulttest(string SP, IEnumerable<SqlParameter>? Params = null)
        {
                var dt = new DataTable();
            try
            {
                using var cnn = new SqlConnection(this.Conn);
                using var adaptor = new SqlDataAdapter(SP, cnn);
                adaptor.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (Params != null)
                {
                    foreach (var param in Params)
                    {
                        if (!param.ToString().Contains("udt"))
                            adaptor.SelectCommand.Parameters.AddWithValue(param.ParameterName, param.Value);
                        if (param.ToString().Contains("udt"))
                            adaptor.SelectCommand.Parameters.AddWithValue("@udt_contact1", param.Value);
                    }
                }
                await cnn.OpenAsync();
                adaptor.Fill(dt);
            
             }
            catch (Exception e)
            {
                //  Block of code to handle errors
                var result = e.Message;
            }
                return dt;
}

        public Task<ContentResult> JsonConverter(DataTable dt)
        {
            var options = new JsonSerializerOptions()
            {
                Converters = { new DataTableConverter() }
            };
            string jsonDataTable = JsonSerializer.Serialize(dt, options);
            var content = new ContentResult();
            content.Content = jsonDataTable;
            content.ContentType = "application/json";
            return Task.FromResult(content);
        }

        public async Task<ContentResult> JsonConverter1(DataTable dt)
        {
            var options = new JsonSerializerOptions()
            {
                Converters = { new ModuleJSON() }
            };
            string jsonDataTable = JsonSerializer.Serialize(dt, options);
            var content = new ContentResult();
            content.Content = jsonDataTable;
            content.ContentType = "application/json";
            return content;
        }

        public  DataTable Report(string SP, IEnumerable<SqlParameter>? Params = null)
        {
            var dt = new DataTable();
            try
            {
                using var cnn = new SqlConnection(this.Conn);
                using var adaptor = new SqlDataAdapter(SP, cnn);
                adaptor.SelectCommand.CommandType = CommandType.StoredProcedure;
                if (Params != null)
                {
                    foreach (var param in Params)
                    {
                        adaptor.SelectCommand.Parameters.AddWithValue(param.ParameterName, param.Value);
                    }
                }
                cnn.OpenAsync();
                adaptor.Fill(dt);
            }
            catch (Exception e)
            {
                //  Block of code to handle errors
            }
            return dt;
        }

        public DataTable ConvertListToDataTable<T>(List<T> list)
        {
            DataTable dataTable = new DataTable();
            PropertyInfo[] properties = typeof(T).GetProperties();

            foreach (PropertyInfo property in properties)
            {
                Type propertyType = property.PropertyType;

                // Check if the property type is nullable
                if (propertyType.IsGenericType && propertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                {
                    // Use the underlying non-nullable type
                    propertyType = Nullable.GetUnderlyingType(propertyType);
                }

                dataTable.Columns.Add(property.Name, propertyType);
            }

            foreach (T item in list)
            {
                DataRow row = dataTable.NewRow();

                foreach (PropertyInfo property in properties)
                {
                    object value = property.GetValue(item);

                    // Check if the value is null and replace it with DBNull.Value
                    if (value == null)
                    {
                        row[property.Name] = DBNull.Value;
                    }
                    else
                    {
                        row[property.Name] = value;
                    }
                }

                dataTable.Rows.Add(row);
            }

            return dataTable;
        }



    }
}
