﻿using System.Data;
using System.Text.Json.Serialization;
using System.Text.Json;
using System.Data.Common;

namespace GymProAPI.GlobalCode
{
     public class ModuleJSON : JsonConverter<DataTable>
        {
            public override DataTable Read(ref Utf8JsonReader reader, Type typeToConvert,
                JsonSerializerOptions options)
            {
                throw new NotImplementedException();
            }

            public override void Write(Utf8JsonWriter writer, DataTable value, JsonSerializerOptions options)
            {
                string MainModule = "";
                int MainModule1 = 0;
                writer.WriteStartArray();
                foreach (DataRow row in value.Rows)
                {
                        var columnValue2 = row["Main_Module"];
                        writer.WriteStartObject();
                        if (MainModule != (string)columnValue2)
                        {
                            if (columnValue2 == null || columnValue2 is DBNull) columnValue2 = "null";
                            writer.WritePropertyName("Main_Module");
                            JsonSerializer.Serialize(writer, columnValue2, options);

                            object main_icon = row["main_icon"];
                            if (main_icon == null || main_icon is DBNull) main_icon = "null";
                            writer.WritePropertyName("main_icon");
                            JsonSerializer.Serialize(writer, main_icon, options);

                            writer.WritePropertyName("Sub");
                            writer.WriteStartArray();
                            writer.WriteStartObject();
                        }

                        MainModule = (string)columnValue2;


                        object columnValue3 = row["Sub_Module"];
                        if (columnValue3 == null || columnValue3 is DBNull) columnValue3 = "null";
                        writer.WritePropertyName("Sub_Module");
                        JsonSerializer.Serialize(writer, columnValue3, options);

                        object columnValue1 = row["PID"];
                        if (columnValue1 == null || columnValue1 is DBNull) columnValue1 = "null";
                        writer.WritePropertyName("PID");
                        JsonSerializer.Serialize(writer, columnValue1, options);

                        object columnValue4 = row["Create_Date"];
                        if (columnValue4 == null || columnValue4 is DBNull) columnValue4 = "null";
                        writer.WritePropertyName("Create_Date");
                        JsonSerializer.Serialize(writer, columnValue4, options);

                        object columnValue5 = row["controller"];
                        if (columnValue5 == null || columnValue5 is DBNull) columnValue5 = "null";
                        writer.WritePropertyName("controller");
                        JsonSerializer.Serialize(writer, columnValue5, options);

                        object columnValue6 = row["icon"];
                        if (columnValue6 == null || columnValue6 is DBNull) columnValue6 = "null";
                        writer.WritePropertyName("icon");
                        JsonSerializer.Serialize(writer, columnValue6, options);

                        object columnValue7 = row["grid_controller"];
                        if (columnValue7 == null || columnValue7 is DBNull) columnValue7 = "null";
                        writer.WritePropertyName("grid_controller");
                        JsonSerializer.Serialize(writer, columnValue7, options);

                        writer.WriteEndObject();

                        object Row_Number = row["Row_Number"];
                        MainModule1 = (int)(long)Row_Number;
                        if (MainModule1 == 1)
                        {
                            writer.WriteEndArray();
                            writer.WriteEndObject();

                        }

                        
                }
                writer.WriteEndArray();
            }
        }
    
}
