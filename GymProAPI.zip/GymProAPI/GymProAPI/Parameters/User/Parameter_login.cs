﻿using GymProAPI.Model.User;
using System.Collections.ObjectModel;
using System.Data.SqlClient;

namespace GymProAPI.Parameters.User
{
    public class Parameter_login
    {
        public Collection<SqlParameter> Parameters(UserModel objE)
        {
            var Params = new Collection<SqlParameter>();
            Params.Add(new SqlParameter("@Username", objE.Username));
            Params.Add(new SqlParameter("@Password", objE.Password));
            return Params;
        }
    }
}
